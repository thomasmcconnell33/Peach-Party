#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"

// Students:  Add code to this file, Actor.cpp, StudentWorld.h, and StudentWorld.cpp

class StudentWorld;

class Actor : public GraphObject
{
public:
	Actor(int imageID, int startX, int startY, StudentWorld* world, int dir = right, int depth = 0) :GraphObject(imageID, startX, startY, dir, depth), m_world(world) {}
	virtual void doSomething() = 0 {} // DO I NEED?
	virtual ~Actor() {} // DO I NEED?
protected:
	StudentWorld* getWorld() const {
		return m_world;
	}
private:
	StudentWorld* m_world;
};

class Mover : public Actor {
public:
	Mover(int imageID, int startX, int startY, StudentWorld * world) : Actor(imageID, startX, startY, world) {}
	virtual void doSomething() = 0 {} // DO I NEED?
	virtual ~Mover() {} // DO I NEED?
protected:
	int getTicksToMove() const {
		return ticks_to_move;
	}
	void changeTicksToMove(int ticks){
		ticks_to_move += ticks;
	}
	int getWalkDir() const {
		return m_walkDirection;
	}
	void changeWalkDir(int newDir) {
		m_walkDirection = newDir;
	}
private:
	int ticks_to_move=0;
	int m_walkDirection=right;
};

class playerAvatar : public Mover {
public:
	playerAvatar(int imageID, int startX, int startY, StudentWorld* world, int playerNumber) : Mover(imageID, startX, startY, world) {
		waitingToRoll = true;
		m_playerNumber = playerNumber;
	}
	virtual void doSomething();
	virtual ~playerAvatar() {  } // AHHH
	// keep track of whether player1 or player2
private:
	bool waitingToRoll;
	int m_playerNumber;
	int die_roll = 0;
};

class Square : public Actor {
public:
	Square(int imageID, int startX, int startY, StudentWorld* world, int dir = right, int depth = 1) : Actor(imageID, startX, startY, world, dir, depth) {}
	virtual void doSomething() = 0 {}
	virtual ~Square() {} // DO I NEED?
protected:
	bool isAlive() {
		return m_alive;
	}
	void killSquare() {
		m_alive = false;
	}
private:
	bool m_alive = true;
};

class coinSquare : public Square {
public:
	coinSquare(int imageID, int startX, int startY, StudentWorld* world, char color) : Square(imageID, startX, startY, world), m_color(color) {}
	virtual void doSomething();
	virtual ~coinSquare() {}
private:
	int m_color; // determines if +3 or -3
};


#endif // ACTOR_H_
