#include "StudentWorld.h"
#include "GameConstants.h"
#include <string>
#include "Actor.h"
#include "Board.h" // required to use our provided class

using namespace std;

GameWorld* createStudentWorld(string assetPath)
{
	return new StudentWorld(assetPath);
}

// Students:  Add code to this file, StudentWorld.h, Actor.h, and Actor.cpp

StudentWorld::StudentWorld(string assetPath)
: GameWorld(assetPath)
{
    m_peach = nullptr;
    //m_yoshi = nullptr;
}

int StudentWorld::init()
{
	startCountdownTimer(99);  // this placeholder causes timeout after 5 seconds

    
    Board bd;
    char bdNum = '0' + getBoardNumber();
    string board_file = assetPath() + "board0" + bdNum + ".txt";
    Board::LoadResult result = bd.loadBoard(board_file);
    if (result == Board::load_fail_file_not_found)
        cerr << "Could not find board01.txt data file\n";
    else if (result == Board::load_fail_bad_format)
        cerr << "Your board was improperly formatted\n";
    else if (result == Board::load_success) {
        cerr << "Successfully loaded board\n";
        for (int i = BOARD_WIDTH - 1; i >= 0; i--) {
            for (int j = 0; j < BOARD_HEIGHT; j++) {
                Board::GridEntry ge = bd.getContentsOf(i, j); // x=i, y=j
                switch (ge) {
                case Board::empty:
                    cout << "Location " << i << "," << j <<" is empty\n";
                    break;
                case Board::boo:
                    cout << "Location " << i << "," << j << " has a Boo and a blue coin square\n";
                    //m_board[i][j] = '+';
                    break;
                case Board::bowser:
                    cout << "Location " << i << "," << j << " has a Bowser and a blue coin square\n";
                    //m_board[i][j] = '+';
                    break;
                case Board::player:
                    cout << "Location " << i << "," << j << " has Peach & Yoshi and a blue coin square\n";
                    m_peach = new playerAvatar(IID_PEACH, i * SPRITE_WIDTH, j * SPRITE_HEIGHT, this, 1);
                    //m_yoshi = new playerAvatar(IID_YOSHI, i * SPRITE_WIDTH, j * SPRITE_HEIGHT, this, 2);
                    m_actors.push_back(new coinSquare(IID_BLUE_COIN_SQUARE, i * SPRITE_WIDTH, j * SPRITE_HEIGHT, this, 'b'));
                    //m_board[i][j] = '+';
                    break;
                case Board::red_coin_square:
                    cout << "Location " << i << "," << j << " has a red coin square\n";
                    m_actors.push_back(new coinSquare(IID_RED_COIN_SQUARE, i * SPRITE_WIDTH, j * SPRITE_HEIGHT, this, 'r'));
                    //m_board[i][j] = '-';
                    break;
                case Board::blue_coin_square:
                    cout << "Location " << i << "," << j << " has a blue coin square\n";
                    m_actors.push_back(new coinSquare(IID_BLUE_COIN_SQUARE, i * SPRITE_WIDTH, j * SPRITE_HEIGHT, this, 'b'));
                    //m_board[i][j] = '+';
                    break;
                    // etc�
                default:
                    cout << "Not yet implemented" << endl;
                }
            }
        }
    }

    return GWSTATUS_CONTINUE_GAME;
}

int StudentWorld::move()
{
    // This code is here merely to allow the game to build, run, and terminate after you hit ESC.
    // Notice that the return value GWSTATUS_NOT_IMPLEMENTED will cause our framework to end the game.

    setGameStatText("Game will end in a few seconds");
    
    if (timeRemaining() <= 0) {
        //play SOUND_GAMe...
        // call setFinalScore()...
        // if peach won...
        return GWSTATUS_NOT_IMPLEMENTED;
    }
    m_peach->doSomething();
    //m_yoshi->doSomething();
    vector<Actor*>::iterator it = m_actors.begin();
    while (it != m_actors.end()) {
        (*it)->doSomething();
        it++;
    }
	return GWSTATUS_CONTINUE_GAME;
}

void StudentWorld::cleanUp()
{
    if (m_peach != nullptr) {
        delete m_peach;
        m_peach = nullptr;
    }
    //delete m_yoshi;
    vector<Actor*>::iterator it = m_actors.begin();
    while (it != m_actors.end()) {
        if (*it!=nullptr)
            delete* it;
        it = m_actors.erase(it);
    }
}
