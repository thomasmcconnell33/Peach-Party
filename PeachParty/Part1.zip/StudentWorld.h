#ifndef STUDENTWORLD_H_
#define STUDENTWORLD_H_

#include "GameWorld.h"
#include "Board.h"
#include "Actor.h"
#include <string>
#include <vector>

// Students:  Add code to this file, StudentWorld.cpp, Actor.h, and Actor.cpp

class StudentWorld : public GameWorld
{
public:
  StudentWorld(std::string assetPath);
  virtual int init();
  virtual int move();
  virtual void cleanUp();
  ~StudentWorld() {
	  cleanUp();
  }
  /*
  char getBoardAt(int x, int y) { // DO I NEED?
	  return m_board[x][y];
  }
  */

  bool contains(int x, int y) const {
	  std::vector<Actor*>::const_iterator it;
	  it = m_actors.begin();
	  while (it != m_actors.end()) {
		  if ((*it)->getX() == x && (*it)->getY() == y)
			  return true;
		  it++;
	  }
	  return false;
  }
private:
	playerAvatar* m_peach;
	//playerAvatar* m_yoshi;
	std::vector<Actor*> m_actors;
	//char m_board[BOARD_WIDTH][BOARD_HEIGHT] = { ' ' }; // DO I NEED?
};

#endif // STUDENTWORLD_H_
