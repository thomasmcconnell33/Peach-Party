#include "Actor.h"
#include "StudentWorld.h"
#include <cmath>

using namespace std;

// Students:  Add code to this file, Actor.h, StudentWorld.h, and StudentWorld.cpp

void playerAvatar::doSomething() {
	if (waitingToRoll) {
		/*
		a. If the Avatar has an invalid direction (due to being teleported):
			i. Pick a random valid direction (there must be a square in that
				direction).
			ii. Update the direction the Avatar's sprite faces based on the walk
				direction: if the walk direction is left, the sprite direction must be
				180 degrees; for all other walk directions, the sprite direction must
				be 0 degrees.
			iii. Continue with step b.
		*/
		
		switch (getWorld()->getAction(m_playerNumber))
		{
		case ACTION_NONE:
			// no key relevant to this player was hit ...
			break;
		case ACTION_FIRE:
			//add Vortex object in front of player...;
			break;
		case ACTION_ROLL:
			die_roll = randInt(1, 10);
			changeTicksToMove( die_roll * 8);
			waitingToRoll = false;
			break;
		}
	}
	
	if (!waitingToRoll) {	
		if (getWalkDir() == right) {
			if (getX() >= VIEW_WIDTH || !getWorld()->contains(getX() / SPRITE_WIDTH * SPRITE_WIDTH + SPRITE_WIDTH, getY())) {
				if (getWorld()->contains(getX(), getY() + SPRITE_HEIGHT)) {
					changeWalkDir(up);
				}
				else if (getWorld()->contains(getX(), getY() - SPRITE_HEIGHT)) {
					changeWalkDir(down);
				}
				else {
					changeWalkDir( left);
				}
			}	
		} 
		else if (getWalkDir()== left) {
			if (getX() < 0 || !getWorld()->contains(ceil(static_cast<double>(getX()) / SPRITE_WIDTH) * SPRITE_WIDTH - SPRITE_WIDTH, getY())) {
				if (getWorld()->contains(getX(), getY() + SPRITE_HEIGHT)) {
					changeWalkDir(  up);
				}
				else if (getWorld()->contains(getX(), getY() - SPRITE_HEIGHT)) {
					changeWalkDir( down);
				}
				else {
					changeWalkDir( right);
				}
			}
		}
		else if (getWalkDir()== up) {
			if (getY() >= VIEW_HEIGHT || !getWorld()->contains(getX(), getY() / SPRITE_HEIGHT * SPRITE_HEIGHT + SPRITE_HEIGHT)) {
				if (getWorld()->contains(getX() + SPRITE_WIDTH, getY())) {
					changeWalkDir( right);
				}
				else if (getWorld()->contains(getX() - SPRITE_WIDTH, getY())) {
					changeWalkDir( left);
				}
				else {
					changeWalkDir( down);
				}
			}
		}
		else if (getWalkDir()== down) {
			if (getY() < 0 || !getWorld()->contains(getX(), ceil(static_cast<double>(getY()) / SPRITE_HEIGHT) * SPRITE_HEIGHT - SPRITE_HEIGHT)) {
				if (getWorld()->contains(getX() + SPRITE_WIDTH, getY())) {
					changeWalkDir( right);
				}
				else if (getWorld()->contains(getX() - SPRITE_WIDTH, getY())) {
					changeWalkDir( left);
				}
				else {
					changeWalkDir( up);
				}
			}
		}
		if (getWalkDir()== left)
			setDirection(left);
		else
			setDirection(right);

		moveAtAngle(getWalkDir(), 2); // move the object 2 pixels
		cout << getX() << "," << getY() << endl;
		changeTicksToMove(-1);
		if (getTicksToMove() == 0) {
			waitingToRoll = true;
		}
		
	}
}

void coinSquare::doSomething() {
	
	if (!isAlive())
		return;
}

